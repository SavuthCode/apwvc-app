<div id="home" class="container tab-pane active" style="margin-top:20px;">
            <div class="row" style="margin-bottom: 14px;">
              <div class="col-6 col-sm-6 col6new">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n1.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="{{url('frontend/detail-page')}}" style="color:red">ចក្ដវាកជាតក</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>ព្រះសាស្ដាកាលស្ដេចគង់នៅវត្តជេតពន ទ្រង់ប្រារព្ធលោលភិក្ខុ (ភិក្ខុល្មោភ) មួយរូប បានត្រាស់ព្រះ</p>
                </div>
              </div>
              <div class="col-6 col-sm-6 col6new1">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n1.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">ចក្ដវាកជាតក</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>ព្រះសាស្ដាកាលស្ដេចគង់នៅវត្តជេតពន ទ្រង់ប្រារព្ធលោលភិក្ខុ (ភិក្ខុល្មោភ) មួយរូប បានត្រាស់ព្រះ</p>
                </div>
              </div>
            </div>

            <div class="row" style="margin-bottom: 14px;">
              <div class="col-6 col-sm-6 col6new">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n1.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">ចក្ដវាកជាតក</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>ព្រះសាស្ដាកាលស្ដេចគង់នៅវត្តជេតពន ទ្រង់ប្រារព្ធលោលភិក្ខុ (ភិក្ខុល្មោភ) មួយរូប បានត្រាស់ព្រះ</p>
                </div>
              </div>
              <div class="col-6 col-sm-6 col6new1">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n1.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">ចក្ដវាកជាតក</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>ព្រះសាស្ដាកាលស្ដេចគង់នៅវត្តជេតពន ទ្រង់ប្រារព្ធលោលភិក្ខុ (ភិក្ខុល្មោភ) មួយរូប បានត្រាស់ព្រះ</p>
                </div>
              </div>
            </div>
            
            <div class="row" style="margin-bottom: 14px;">
              <div class="col-6 col-sm-6 col6new">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n1.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">ចក្ដវាកជាតក</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>ព្រះសាស្ដាកាលស្ដេចគង់នៅវត្តជេតពន ទ្រង់ប្រារព្ធលោលភិក្ខុ (ភិក្ខុល្មោភ) មួយរូប បានត្រាស់ព្រះ</p>
                </div>
              </div>
              <div class="col-6 col-sm-6 col6new1">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n1.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">ចក្ដវាកជាតក</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>ព្រះសាស្ដាកាលស្ដេចគង់នៅវត្តជេតពន ទ្រង់ប្រារព្ធលោលភិក្ខុ (ភិក្ខុល្មោភ) មួយរូប បានត្រាស់ព្រះ</p>
                </div>
              </div>
            </div>
            
            <div class="row" style="margin-bottom: 14px;">
              <div class="col-6 col-sm-6 col6new">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n1.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">ចក្ដវាកជាតក</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>ព្រះសាស្ដាកាលស្ដេចគង់នៅវត្តជេតពន ទ្រង់ប្រារព្ធលោលភិក្ខុ (ភិក្ខុល្មោភ) មួយរូប បានត្រាស់ព្រះ</p>
                </div>
              </div>
              <div class="col-6 col-sm-6 col6new1">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n1.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">ចក្ដវាកជាតក</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>ព្រះសាស្ដាកាលស្ដេចគង់នៅវត្តជេតពន ទ្រង់ប្រារព្ធលោលភិក្ខុ (ភិក្ខុល្មោភ) មួយរូប បានត្រាស់ព្រះ</p>
                </div>
              </div>
            </div>
          </div>