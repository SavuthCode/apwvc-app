<div class="tab-pane fade" id="videosdd" role="tabpanel" aria-labelledby="nav-profile-tab"></br>
  <div class="row">
    <div class="col-4 bookCol4" style="padding-left:15px;padding-right:0px">
      <div class="image-book">
      <iframe width="100%" height="255px" src="https://www.youtube.com/embed/XSz0hPn6mSU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <!-- <img class="card-img-bottom" src="{{asset('images/new/n6.jpg')}}" alt="Card image" style="width:100%;height:255px;"> -->
      </div>
      <!-- <div class="icon-video">
        <img src="{{asset('images/book/icon-video.png')}}" />
      </div> -->
      <div class="book-text" style="padding:5px;">
        <p class="card-title"><a href="{{url('frontend/detail-page')}}" style="color:red">សកម្មភាពមនុស្សធម៌របស់ថ្នាក់ដឹកនាំសមាគមនពេលកន្លងមក</a></p>
        <h5 class="card-text">Ven sokvuth</h5>
      </div>
    </div>
    <div class="col-4 bookCol4">
      <div class="image-book">
      <iframe width="100%" height="255px" src="https://www.youtube.com/embed/LKUk1N1yDgU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <!-- <img class="card-img-bottom" src="{{asset('images/book/b2.jpg')}}" alt="Card image" style="width:100%;height:255px;"> -->
      </div>
      <div class="book-text" style="padding:5px;">
        <p class="card-title"><a href="" style="color:red">សកម្មភាពសប្បុរសធម៌របស់ថ្នាក់ដឹកនាំសមាគមនពេលកន្លងមក</a></p>
        <h5 class="card-text">Ven sokvuth</h5>
      </div>
    </div>
    <div class="col-4 bookCol4" style="padding-left: 0px;">
      <div class="image-book">
      <iframe width="100%" height="255px" src="https://www.youtube.com/embed/8MnxrffuC-M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <!-- <img class="card-img-bottom" src="{{asset('images/book/b1.jpg')}}" alt="Card image" style="width:100%;height:255px;"> -->
      </div>
      <div class="book-text" style="padding:5px;">
        <p class="card-title"><a href="" style="color:red">នាព្រឹកថ្ងៃទី១៦ខែកញ្ញាឆ្នាំ២០២២ កម្មវិធីចំនួនពីរក្នុងស្រុកស្រីស្នំ ខេត្តសៀមរាប</a></p>
        <h5 class="card-text">Ven sokvuth</h5>
      </div>
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-4 bookCol4" style="padding-left:15px;padding-right:0px">
      <div class="image-book">
      <iframe width="100%" height="255px" src="https://www.youtube.com/embed/xwQuDFBlRHg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <!-- <img class="card-img-bottom" src="{{asset('images/book/b1.jpg')}}" alt="Card image" style="width:100%;height:255px;"> -->
      </div>
      <div class="book-text" style="padding:5px;">
        <p class="card-title"><a href="" style="color:red">សកម្មភាពសប្បុរសធម៌របស់ថ្នាក់ដឹកនាំសមាគមនពេលកន្លងមក</a></p>
        <h5 class="card-text">Ven sokvuth</h5>
      </div>
    </div>
    <div class="col-4 bookCol4">
      <div class="image-book">
      <iframe width="100%" height="255px" src="https://www.youtube.com/embed/Va-tFV1G8Uk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <!-- <img class="card-img-bottom" src="{{asset('images/book/b2.jpg')}}" alt="Card image" style="width:100%;height:255px;"> -->
      </div>
      <div class="book-text" style="padding:5px;">
        <p class="card-title"><a href="" style="color:red">សកម្មភាពមនុស្សធម៌របស់ថ្នាក់ដឹងនាំសមាគមនពេលកន្លងមក</a></p>
        <h5 class="card-text">Ven sokvuth</h5>
      </div>
    </div>
    <div class="col-4 bookCol4" style="padding-left: 0px;">
      <div class="image-book">
      <iframe width="100%" height="255px" src="https://www.youtube.com/embed/TCcIt44aL_M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <!-- <img class="card-img-bottom" src="{{asset('images/book/b1.jpg')}}" alt="Card image" style="width:100%;height:255px;"> -->
      </div>
      <div class="book-text" style="padding:5px;">
        <p class="card-title"><a href="" style="color:red">សកម្មភាពមនុស្សធម៌របស់ថ្នាក់ដឹងនាំសមាគមនពេលកន្លងមក</a></p>
        <h5 class="card-text">Ven sokvuth</h5>
      </div>
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-4 bookCol4" style="padding-left:15px;padding-right:0px">
      <div class="image-book">
      <iframe width="100%" height="255px" src="https://www.youtube.com/embed/Bx4IMp3aQcM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <!-- <img class="card-img-bottom" src="{{asset('images/book/b1.jpg')}}" alt="Card image" style="width:100%;height:255px;"> -->
      </div>
      <div class="book-text" style="padding:5px;">
        <p class="card-title"><a href="" style="color:red">សកម្មភាពមនុស្សធម៌របស់ថ្នាក់ដឹកនាំសមាគមនពេលកន្លងមក</a></p>
        <h5 class="card-text">Ven sokvuth</h5>
      </div>
    </div>
    <div class="col-4 bookCol4">
      <div class="image-book">
      <iframe width="100%" height="255px" src="https://www.youtube.com/embed/Bx4IMp3aQcM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <!-- <img class="card-img-bottom" src="{{asset('images/book/b2.jpg')}}" alt="Card image" style="width:100%;height:255px;"> -->
      </div>

      <div class="book-text" style="padding:5px;">
        <p class="card-title"><a href="" style="color:red">សកម្មភាពមនុស្សធម៌របស់ថ្នាក់ដឹកនាំសមាគមនាពេលកន្លងមក</a></p>
        <h5 class="card-text">Ven sokvuth</h5>
      </div>
    </div>
    <div class="col-4 bookCol4" style="padding-left: 0px;">
      <div class="image-book">
      <iframe width="100%" height="255px" src="https://www.youtube.com/embed/CikkCHqNxNU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        <!-- <img class="card-img-bottom" src="{{asset('images/book/b1.jpg')}}" alt="Card image" style="width:100%;height:255px;"> -->
      </div>
      <div class="book-text" style="padding:5px;">
        <p class="card-title"><a href="" style="color:red">សកម្មភាពមនុស្សធម៌របស់ថ្នាក់ដឹកនាំសមាគមនពេលកន្លងមក</a></p>
        <h5 class="card-text">Ven sokvuth</h5>
      </div>
    </div>
  </div>
  <br>
  <center>
      <button class="btn btn-info">More...</button>
  </center>
</div>
