<div id="home" class="container  tab-pane active" style="margin-top:-17px;"><br>
            <div class="row ">
              <div class="col-6 col-sm-6 col6new">
                <div class="image-content">
                <a href="{{url('frontend/detail-page')}}"><img src="{{asset('frontend/images/new/n1.jpg')}}" alt="Card image" style="width:100%;height:200px;" /></a>
                </div>
                <div class="social">
                  <div class="float-right" style="margin-top: -2px;">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="{{url('frontend/detail-page')}}" style="color:red">ddសកម្មភាពសប្បុរសធម៌របស់ថ្នាក់ដឹកនាំសមាគមនាពេលកន្លងមក</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>នាព្រឹកថ្ងៃទី០៦ ខែតុលា ឆ្នាំ២០២២ យោងតាមសំណើរ របស់លោកនាយក លោកគ្រូ អ្នកគ្រូនិងសិស្សានុសិស្សវិទ្យាល័យ២៨...</p>
                </div>
              </div>
              <div class="col-6 col-sm-6 col6new1">
                <div class="image-content">
                <a href="{{url('frontend/detail-page')}}"><img src="{{asset('frontend/images/new/n2.jpg')}}" alt="Card image" style="width:100%;height:200px;" /></a>
                </div>
                <div class="social">
                  <div class="float-right" style="margin-top: -2px;">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="{{url('frontend/detail-page')}}" style="color:red">សកម្មភាពសប្បុរសធម៌របស់ថ្នាក់ដឹកនាំសមាគមនាពេលកន្លងមក</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>នាព្រឹកថ្ងៃទី២៦ ខែកញ្ញា ឆ្នាំ២០២២ ស្រុកស្រីស្នំ ខេត្តសៀមរាប😍...
🙏ថ្នាក់ដឹកសមាគមលើកកម្ពស់ពលករ និងអតីតពលករ ដើម្បីសប្បុរសធម៌  </p>
                </div>
              </div>
            </div>

            <div class="row row_new">
              <div class="col-6 col-sm-6 col6new">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n3.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right" style="margin-top: -2px;">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">ចក្ដវាកជាតក</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>សកម្មភាពសប្បុរសធម៌របស់ថ្នាក់ដឹកនាំសមាគមនាពេលកន្លងមក🙏
ខេត្តបាត់ដំបងកាលពីថ្ងៃទី១៣ ខែវិច្ឆិកា ឆ្នាំ២០២១!
លោក អឿន ហ៊ួត ជាតំណាងដ៏ខ្ពង់ខ្ពស់លោកស្រី ឡេង ចាន់ណា</p>
                </div>
              </div>
              <div class="col-6 col-sm-6 col6new1">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n4.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right" style="margin-top: -2px;">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">បុណ្យភ្ជុំបិណ្ឌ</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>សូមអនុមោទនា "បុណ្យភ្ជុំបិណ្ឌ"🙏🙏🙏
​ថ្ងៃអង្គារ បិណ្ឌ១០ ខែភទ្របទ ឆ្នាំខាល ​​ចត្វាស័ក ពុទ្ធសករាជ ២៥៦៦
ត្រត្រូវនឹងថ្ងៃទី២០ ខែកញ្ញា ឆ្នាំ២០២២!
ក្នុងឱកាស ពិធីបុណ្យភ្ជុំបិណ្ឌ ប្រពៃណីជាតិខ្មែរ...</p>
                </div>
              </div>
            </div>

            <div class="row row_new">
              <div class="col-6 col-sm-6 col6new">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n5.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right" style="margin-top: -2px;">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">ប្រធានក្រុមការងាររាជរដ្ឋាភិបាលចុះមូលដ្ឋានស្រុកស្រីស្នំ</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>នាព្រឹកថ្ងៃទី១៦ខែកញ្ញាឆ្នាំ២០២២ 💝💝💝
🙏ថ្នាក់ដឹកនាំសមាគមលើកកម្ពស់ពលករនិងអតីតពលករ... </p>
                </div>
              </div>
              <div class="col-6 col-sm-6 col6new1">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n6.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right" style="margin-top: -2px;">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">សកម្មភាពសប្បុរសធម៌របស់ថ្នាក់ដឹកនាំសមាគមនា</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>សកម្មភាពសប្បុរសធម៌របស់ថ្នាក់ដឹកនាំសមាគមនាពេលកន្លងមក🙏
ខេត្តកំពង់ធំកាលពីព្រឹកថ្ងៃទី៣០</p>
                </div>
              </div>
            </div>

            <div class="row row_new">
              <div class="col-6 col-sm-6 col6new">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n7.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right" style="margin-top: -2px;">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">អភិបាលនៃគណៈអភិបាលខេត្តបន្ទាយមានជ័យ និងលោកជំទាវ</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>សកម្មភាពមនុស្សធម៌របស់ថ្នាក់ដឹកនាំសមាគមនាពេលកន្លងមក🙏🥰
ខេត្តបន្ទាយមានជ័យនាថ្ងៃទី២៥ ខែតុលា ឆ្នាំ២០២០‼️
តាមរយះឯកឧត្តម អ៊ុំ រាត្រី អភិបាលនៃគណៈអភិបាលខេត្តបន្ទាយមានជ័យ និងលោកជំទាវ។</p>
                </div>
              </div>
              <div class="col-6 col-sm-6 col6new1">
                <div class="image-content">
                  <img src="{{asset('frontend/images/new/n1.jpg')}}" alt="Card image" style="width:100%;height:200px;" />
                </div>
                <div class="social">
                  <div class="float-right" style="margin-top: 5px;">
                    <img src="{{asset('frontend/images/download-removebg-preview.png')}}" style="width:20px;height:20px;"/>
                    <img src="{{asset('frontend/images/Twitter-logo-png.png')}}" style="width:20px;height:20px;"/>
                  </div>
                </div>
                <div class="textnew">
                  <h5 class="card-title"><a href="" style="color:red">សកម្មភាពមនុស្សធម៌របស់ថ្នាក់ដឹកនាំ</a></h5>
                  <p class="card-text">Public Date: 2022-09-20 <br>សកម្មភាពមនុស្សធម៌របស់ថ្នាក់ដឹកនាំសមាគមនាពេលកន្លងមក‼️
ខេត្តសៀមរាប នាថ្ងៃទី២៨ ខែតុលា ឆ្នាំ២០២០ (ក្នុងស្រុកស្រីស្នំ)
តាមរយះឯកឧត្តម ស៊ាន បូរ៉ាត់ រដ្ឋលេខាធិការក្រសួងអប់រំយុវជន និងកីឡា និងជាប្រធានក្រុមការងាររាជរដ្ឋាភិបាលចុះមូលដ្ឋានស្រុកស្រីស្នំ។</p>
                </div>
              </div>
            </div>
            <br>
            <center style="margin-top: -15px;"><button class="btn btn-primary">Read more...</button></center>
          </div>