<div class="wrapper" style="font-family:khmer os content">
<div class="logo">
    <img src="http://localhost:8000/logo/20221026080732.jpg"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <div class="logo-name">
        សាមគមលើកកម្ពស់ពលករ អតីតពលករដើម្បីសប្បុរសធម៌ 
        <br/>
        Association for the Promotion of Workers and Veterans for Charity
    </div>
            
    </div>
  
  <nav>
  <div class="container">
    <div class="container-fluid">
    <label for="drop" class="toggle">
    <div class="container" onclick="myFunction(this)" style="color:white:0px;font-size:10px;">
      <div class="bar1" style="color:white"></div>
      <div class="bar2" style="color:white"></div>
      <div class="bar3" style="color:white"></div>
    </div>
    </label>
    <input type="checkbox" id="drop" />
      <ul class="menu">
        <li><a href="#">ទំព័រដើម</a></li>
        <li><a href="#">ទំនាក់ទំនង</a></li>
        <li><a href="#">អំពីយើង</a></li>
        <li>
          <label for="drop-2" class="toggle">ភាសារ +</label>
          <a href="#"><i class="fa fa-flag"></i> &nbsp;ភាសារ</a>
          <input type="checkbox" id="drop-2"/>
          <ul>

              <li><a href="#"><img scr="{{asset('frontend/images/khmer.jpg')}}">ភាសាខ្មែរ</a></li>
              <li><a href="#"><i class="flag flag-united-states"></i>English</a></li>
          </ul>
        </li>
        <li>
          <label for="drop-3" class="toggle"><i class="fa fa-user"></i> &nbsp;Ven sokvuth + </label>
          <a href="#"><i class="fa fa-user"></i> &nbsp;Ven sokvuth</a>
          <input type="checkbox" id="drop-3"/>
          <ul>

              <li><a href="#">Logout</a></li>
             
              </li>
          </ul>
        </li>
      </ul>
      </div>
      </div>
    </nav>

     
  </div>
</div>
