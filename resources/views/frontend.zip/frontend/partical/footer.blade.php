<!-- Footer -->
<section id="footer" style="font-family:khmer os content">​
		<div class="container">
			<div class="row text-center text-xs-center text-sm-left text-md-left">
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5>ក្រុមហ៊ុន</h5>
					<div class="footer-logo">
					<img src="http://localhost:8000/logo/20221026080732.jpg"/>
					</div>
					<ul class="list-unstyled quick-links">
						<li><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-angle-double-right"></i><i style="color:red">@រក្សាសិទ្ធិដោយ​៖​</i>
						សាមគមលើកកម្ពស់ពលករ អតីតពលករដើម្បីសប្បុរសធម៌</a></li>	
						<li><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-angle-double-right"></i>គោលការណ៏ភាពឯកជន | Privacy Policy</a></li>
					</ul>
					
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5>អំពីយើងខ្ញុំ</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-angle-double-right"></i>សូមទំនាក់ទំនង</a></li>
						<li><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-angle-double-right"></i>លេខទូរស័ព្ទ​​ ៖ ០២៣៩០៩០២៣ / ០២៣៩០៩០២៣</a></li>
						<li><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-angle-double-right"></i>ទូរសារ ៖ apwvc@gmail.com.kh</a></li>
						<li><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-angle-double-right"></i>ទីតាំង ៖ អគ្គារភ្លោះ ផ្លូវ ២៧១, ទួលទំពូង, រាជធានីភ្នំពេញ</a></li>
					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5>ជួបគ្នាតាមបណ្ដាញសង្គម</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-angle-double-right"></i>ទំនាក់ទំនង</a></li>
					</ul>
					<ul class="list-unstyled list-inline ">
						<li class="list-inline-item"><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href="https://www.fiverr.com/share/qb8D02"><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="https://www.fiverr.com/share/qb8D02" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<!-- ./Footer -->