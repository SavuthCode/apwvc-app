<div class="list-group">
		<a href="#" class="list-group-item list-group-item-action" style="padding:10px;">
	
		<div class="text-list float-left" style="margin-top:10px;margin-left:10px;font-size:18px;">
			ពត័មានថ្មីៗ
		</div>
		<div class="list-icon float-right" style="margin-top: 8px;">
			<span class="	fas fa-caret-right"></span>
		</div>
		</a>

		<a href="#" class="list-group-item list-group-item-action" style="padding:10px;">
		<div class="text-list float-left" style="margin-top:10px;margin-left:10px;font-size:18px;">
			ដំណើរទស្សនះកិច្ចរបស់ថ្នាក់ដឹងនាំ
		</div>
		<div class="list-icon float-right" style="margin-top: 8px;">
			<span class="	fas fa-caret-right"></span>
		</div>
		</a>

		<a href="#" class="list-group-item list-group-item-action" style="padding:10px;;font-size:18px;">
		<div class="text-list float-left" style="margin-top:10px;margin-left:10px;font-size:18px;">
			សមាគមលើកកម្ពស់ពលករ
		</div>
		<div class="list-icon float-right" style="margin-top: 8px;">
			<span class="	fas fa-caret-right"></span>
		</div>
		</a>

		<a href="#" class="list-group-item list-group-item-action" style="padding:10px;">
		<div class="text-list float-left" style="margin-top:10px;margin-left:10px;font-size:18px;">
			ព្រឹត្ដិការណ៏ទាន់ហេតុការណ៏
		</div>
		<div class="list-icon float-right" style="margin-top: 8px;">
			<span class="	fas fa-caret-right"></span>
		</div>
		</a>

		<a href="#" class="list-group-item list-group-item-action" style="padding:10px;">
		<div class="text-list float-left" style="margin-top:10px;margin-left:10px;font-size:18px;">
			ពត័មានក្នុងស្រុក
		</div>
		<div class="list-icon float-right" style="margin-top: 8px;">
			<span class="	fas fa-caret-right"></span>
		</div>
		</a>
	</div>
	<div class="menu-keyword" style="margin-top:15px;">
		<div class="card">
		<div class="card-header">
			<div class="float-left text-danger"><h5><i class="fa fa-tags"></i>  Keyword</h5></div>
		</div>
		<div class="card-body" style="padding:5px;">
			<div>
			<span class="badge badge-secondary" style="padding:5px;font-size:12px;">ព្រះគុណពុកម៉ែ</span>
			<span class="badge badge-secondary" style="padding:5px;font-size:12px;">ទ្រង់ប្រារព្ធលោលភិក្ខុម</span>
			<span class="badge badge-secondary" style="padding:5px;font-size:12px;">ទំនួញប្រែត</span>
			<span class="badge badge-secondary" style="padding:5px;font-size:12px;">ទំនួញសុវណ្ណសាម</span>
			<span class="badge badge-secondary" style="padding:5px;font-size:12px;">ធម្មទេសនា</span>
			</div>
		</div>
		</div>
	</div>
	<div class="menu-recently-read" style="margin-top:15px;">
		<div class="card">
		<div class="card-header">
			<div class="float-left text-danger"><h5><i class="fa fa-history"></i>  Recently List / Read</h5></div>
		</div>
		<div class="card-body" style="padding:5px;">
			<div class="row">
			<div class="col-sm-5">
				<div class="img-read">
				<img class="card-img-bottom" src="{{asset('frontend/images/image-content1.jpg')}}" alt="Card image" style="width:100%;">
				
				</div>
			</div>
			<div class="col-sm-7" style="padding-left: 0px;">
				<h6 class="text-danger"><a>Asia's richest man sees isolation for Chin</a></h6>
				<p>inside the box. Note that this will add a scrollbar both horizontally and vertically</p>
			</div>
			</div>
			<div class="row">
			<div class="col-sm-5">
				<div class="img-read">
				<img class="card-img-bottom" src="{{asset('frontend/images/new.jpg')}}" alt="Card image" style="width:100%;">
				</div>
			</div>
			<div class="col-sm-7" style="padding-left: 0px;">
				<h6 class="text-danger"><a>Tampa Bay Buccaneers moving practice</a></h6>
				<p>inside the box. Note that this will add a scrollbar both horizontally and vertically</p>
			</div>
			</div>
			<div class="row">
			<div class="col-sm-5">
				<div class="img-read">
				<img class="card-img-bottom" src="{{asset('frontend/images/hqdefault.jpg')}}" alt="Card image" style="width:100%;">
				
				</div>
			</div>
			<div class="col-sm-7" style="padding-left: 0px;">
				<h6 class="text-danger"><a>Asia's richest man sees isolation for China</a></h6>
				<p>inside the box. Note that this will add a scrollbar both horizontally and vertically</p>
			</div>
			</div>
			<div class="row">
			<div class="col-sm-5">
				<div class="img-read">
				<img class="card-img-bottom" src="{{asset('frontend/images/220926004314-putin-0926-large-tease.jpg')}}" alt="Card image" style="width:100%;">
				
				</div>
			</div>
			<div class="col-sm-7" style="padding-left: 0px;">
				<h6 class="text-danger"><a>ererererer</a></h6>
				<p>inside the box. Note that this will add a scrollbar both horizontally and vertically</p>
			</div>
			</div>
		</div>
		</div>
	</div>
	<!-- ================================advertisement ========================================== -->
	<div class="card advertise" style="width:100%;height:auto;margin-top:15px">
		<div class="card-body" style="padding:0px;">
		<div>
			<img src="https://iotcdn.oss-ap-southeast-1.aliyuncs.com/shampoo.jpg"/ style="width:100%">
		</div>
		</div>
	</div>